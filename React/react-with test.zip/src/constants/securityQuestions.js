
export const SECURITY_QUESTIONS = [
    "What is your hometown name?",
    "What is your favorite color?",
    "What was your first pet's name?",
    "What is your mother's maiden name?",
    "What is your favorite food?"
];
